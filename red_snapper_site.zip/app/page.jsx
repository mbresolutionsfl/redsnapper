export default function Home() {
  return (
    <div style={{ minHeight: "100vh", background: "black", color: "white" }}>
      <h1 style={{ fontSize: "3rem", color: "red", fontWeight: "bold", fontFamily: "Agency FB, Impact, sans-serif", padding: "20px" }}>
        Red Snapper Realty
      </h1>
      <p style={{ paddingLeft: "20px" }}>Your deployment is ready.</p>
    </div>
  );
}
